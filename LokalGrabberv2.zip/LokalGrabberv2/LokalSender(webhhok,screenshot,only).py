import os
import datetime
import requests
from PIL import ImageGrab # For taking screenshots
import json
import sys

def lokal_sending_screenshot_and_upload(webhook_url: str) -> None:
    """
    Captures a screenshot of the primary display and uploads it to the
    specified webhook URL. This script does not rely on PowerShell.

    Args:
        webhook_url (str): The URL of the webhook to send the screenshot to.
    """
    temp_dir = os.environ.get('TEMP')
    if not temp_dir:
        print("[ERROR] TEMP environment variable not found. Exiting.")
        sys.exit(1)

    # --- Setup Screenshot Path ---
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    screenshot_filename = f"Screenshot_{timestamp}.png"
    screenshot_path = os.path.join(temp_dir, screenshot_filename)

    print("\n=========================================================")
    print(" LokalSending: Screenshot & Webhook Uploader")
    print("=========================================================\n")

    if not webhook_url:
        print("[ERROR] No Webhook URL provided. Exiting.")
        return

    # --- Take Screenshot ---
    print("Taking screenshot...")
    try:
        screenshot = ImageGrab.grab() # Captures the primary screen
        screenshot.save(screenshot_path)
        print(f"Screenshot successfully saved: {screenshot_path}")
    except Exception as e:
        print(f"[ERROR] Failed to take screenshot: {e}")
        return

    # --- Upload Screenshot to Webhook ---
    print(f"Sending screenshot to webhook: {webhook_url}")
    try:
        # Prepare JSON payload for the webhook message (e.g., for Discord)
        # 'content' can be an empty string if you only want to send the file.
        payload = {
            "content": f"New screenshot from {os.environ.get('COMPUTERNAME', 'Unknown PC')} at {datetime.datetime.now().strftime('%H:%M:%S')}"
        }

        # Open the screenshot file in binary read mode
        with open(screenshot_path, 'rb') as f:
            # 'files' dictionary for multipart/form-data upload
            files = {
                'file': (screenshot_filename, f, 'image/png'), # 'file' is often the parameter name for file uploads
                'payload_json': (None, json.dumps(payload), 'application/json') # Additional data as a JSON string
            }
            # Send the POST request
            response = requests.post(webhook_url, files=files)
            response.raise_for_status() # Raises an HTTPError for bad responses (4xx or 5xx)

        print("Screenshot successfully sent!")
    except requests.exceptions.RequestException as e:
        print(f"[ERROR] Failed to send screenshot to webhook: {e}")
        print("Please ensure the webhook URL is correct and supports file uploads.")
    except Exception as e:
        print(f"[ERROR] An unexpected error occurred during upload: {e}")
    finally:
        # --- Clean Up Temporary Screenshot File ---
        if os.path.exists(screenshot_path):
            try:
                os.remove(screenshot_path)
                print(f"Temporary screenshot file deleted: {screenshot_path}")
            except OSError as e:
                print(f"Error deleting temporary screenshot file: {e}")
        else:
            print("Temporary screenshot file not found (was it already deleted?).")

    print("\n=========================================================")
    print(" Operation Complete.")
    print("=========================================================\n")

if __name__ == "__main__":
    # --- Main Execution Block ---
    webhook_input = input("Please enter the Webhook URL: ")
    lokal_sending_screenshot_and_upload(webhook_input.strip())
    input("Press Enter to exit...") # Keep the console open until user presses a key